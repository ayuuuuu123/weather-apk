// 顶层构建脚本：只声明插件版本，不在这里应用
plugins {
    id("com.android.application") version "8.7.3" apply false
}
