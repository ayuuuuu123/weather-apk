# 天气 App（Android 原生壳）

一个**真正的 Android 应用**：原生 Activity + WebView 外壳，界面和逻辑就是之前的网页版（`app/src/main/assets/index.html`）。

- 包名：`com.dsh.weather`
- 最低支持：Android 7.0（API 24），按 Android 15（API 35）编译
- 权限：网络、定位（可选，用于「📍 当前位置」）
- 第三方依赖：**0 个**（只用系统 WebView，构建最快、最不容易踩坑）

---

## 方式一：GitHub 一键出 APK（不需要电脑，推荐）

前提：有一个 GitHub 账号（手机浏览器就能注册）。

1. 新建一个仓库（Private 也可以）
2. 把本文件夹**全部内容**上传（网页版 GitHub 支持直接拖文件夹）
3. 打开仓库的 **Actions** 标签页 → 选 `Build APK` → 点 **Run workflow**
4. 等 3~5 分钟，点进这次运行，页面底部 **Artifacts** → 下载 `weather-debug-apk.zip`
5. 解压得到 `app-debug.apk`，传到手机 → 点击安装（需要在设置里允许「安装未知应用」）

---

## 方式二：Android Studio（有电脑最省心）

1. Android Studio → **Open** → 选本文件夹
2. 等 Gradle 同步完成（首次会下载 Gradle 8.9 + AGP 8.7.3，约 200MB）
3. 手机开「开发者选项 → USB 调试」，连电脑 → 点 ▶ Run
   或菜单 **Build → Build App Bundle(s) / APK(s) → Build APK(s)**
4. 产物：`app/build/outputs/apk/debug/app-debug.apk`

## 方式三：命令行（需要 JDK 17）

```bash
# 只需要 JDK 17，Android SDK 由 Gradle 自动下载
java -version          # 确认是 17

./gradlew assembleDebug

# 装到手机（先开 USB 调试）
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Windows 用 `gradlew.bat assembleDebug`。

> 如果 `./gradlew` 报 `gradle-wrapper.jar` 缺失：执行一次 `gradle wrapper --gradle-version 8.9` 重新生成。

---

## 目录结构

```
WeatherApp-Android/
├── settings.gradle.kts           # 仓库 / 模块声明
├── build.gradle.kts              # 顶层插件版本（AGP 8.7.3）
├── gradle.properties
├── gradlew                       # Gradle Wrapper 脚本
├── gradle/wrapper/
│   ├── gradle-wrapper.jar
│   └── gradle-wrapper.properties # Gradle 8.9
├── .github/workflows/
│   └── build-apk.yml             # GitHub Actions 自动出 APK
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/dsh/weather/MainActivity.java   # WebView 外壳
        ├── assets/index.html                        # 全部界面与业务逻辑
        └── res/
            ├── values/strings.xml
            ├── values/themes.xml
            └── mipmap-*/ic_launcher.png             # 5 档密度图标
```

## 改东西改哪里

| 想改 | 改哪个文件 |
|---|---|
| 界面、颜色、天气逻辑、数据源 | `app/src/main/assets/index.html` |
| 应用名（桌面显示） | `res/values/strings.xml` 里的 `app_name` |
| 图标 | 替换 `res/mipmap-*/ic_launcher.png` |
| 包名 / 版本号 | `app/build.gradle.kts` 的 `applicationId` / `versionCode` |
| 启动背景、状态栏颜色 | `res/values/themes.xml` |
| 允许定位吗、站外链接怎么处理 | `MainActivity.java` |

改完 `assets/index.html` 直接重新构建即可，不需要联网。

## 注意事项

- **签名**：`release` 目前复用 debug 签名，方便自己装。要上架或给别人装，请生成自己的 keystore 并配置 `signingConfigs`，否则别人能伪造你的更新包。
- **隐私**：定位权限只在你点「📍」时才申请；App 不上传任何数据，天气请求直连 Open-Meteo。
- **离线**：断网时显示上一次缓存的天气（localStorage）。
- **WebView**：界面依赖系统 WebView，Android 7+ 都内置；极个别精简系统若被禁用，需在设置里启用。
- **为什么不能在这台手机上直接编译**：Android 编译需要 JDK（javac/d8 都是 Java 程序）+ Android SDK 构建工具，手机上没有也无法自举，所以必须借助电脑或 GitHub 的免费构建机。
