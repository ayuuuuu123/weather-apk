plugins {
    id("com.android.application")
}

android {
    namespace = "com.dsh.weather"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.dsh.weather"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }

    buildTypes {
        release {
            // 个人使用：release 也先用 debug 签名，方便直接安装；上架时请换成自己的 keystore
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

// 无第三方依赖：只用 Android 框架自带的 WebView，构建最快、最不容易踩坑
dependencies { }
